from django.urls import path
from . import views

urlpatterns = [

    # Authentication
    path('register/', views.register, name='register'),
    path('', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Dashboard
    path('dashboard/', views.dashboard, name='dashboard'),

    # Disease Prediction
    path('predict/', views.predict_view, name='predict'),

    # Chatbot
    path('chatbot/', views.chatbot_view, name='chatbot'),

    # Nearby Doctors
    path('doctors/', views.doctors_view, name='doctors'),
    #bmii
    path('bmi/', views.bmi_view, name='bmi'),
    #wheather
    path('weather/', views.weather_alert, name='weather'),
    #email notification
    path('email/', views.email_reminder, name='email'),
    #emergency
    path('emergency/', views.emergency_view, name='emergency'),
    #healthh report
    path('reports/', views.report_history, name='report_history'),
    path('report/', views.download_report, name='download_report'),
    

]
