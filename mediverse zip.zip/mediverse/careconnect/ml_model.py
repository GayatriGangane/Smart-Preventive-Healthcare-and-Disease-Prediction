import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "dataset", "Training.csv")

# Load Dataset
df = pd.read_csv(DATA_PATH)

# Drop unnecessary column if exists
if "Unnamed: 133" in df.columns:
    df = df.drop("Unnamed: 133", axis=1)

X = df.drop("prognosis", axis=1)
y = df["prognosis"]

# Train Model
model = RandomForestClassifier()
model.fit(X, y)

# Store symptom names globally
SYMPTOMS_LIST = X.columns.tolist()

def predict_disease(selected_symptoms):
    input_data = [0] * len(SYMPTOMS_LIST)

    for symptom in selected_symptoms:
        if symptom in SYMPTOMS_LIST:
            index = SYMPTOMS_LIST.index(symptom)
            input_data[index] = 1

    prediction = model.predict([input_data])
    return prediction[0]
