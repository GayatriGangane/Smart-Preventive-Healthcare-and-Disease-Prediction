from django.contrib import admin
from .models import HealthReport, Prediction, PatientProfile

@admin.register(HealthReport)
class HealthReportAdmin(admin.ModelAdmin):
    list_display = ('user', 'disease', 'symptoms', 'created_at')
    search_fields = ('user__username', 'disease')

@admin.register(Prediction)
class PredictionAdmin(admin.ModelAdmin):
    list_display = ('patient', 'disease', 'symptoms')
    search_fields = ('patient__username', 'disease')

@admin.register(PatientProfile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'age', 'latitude', 'longitude')
    