from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import RegisterForm, ProfileForm
from .models import PatientProfile, Prediction
import requests
from django.conf import settings
from .models import Prediction,HealthRecord
from .ml_model import predict_disease, SYMPTOMS_LIST
from django.core.mail import send_mail
from reportlab.lib.styles import getSampleStyleSheet
from django.http import HttpResponse
from .models import HealthReport
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors

# ==============================
# REGISTER VIEW
# ==============================
def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        profile_form = ProfileForm(request.POST)

        if form.is_valid() and profile_form.is_valid():
            user = form.save()  # ✅ hashes password properly

            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()

            return redirect('login')  # go to login page

        else:
            print(form.errors)         # 🔍 debug if needed
            print(profile_form.errors)

    else:
        form = RegisterForm()
        profile_form = ProfileForm()

    return render(request, 'register.html', {
        'form': form,
        'profile_form': profile_form
    })

# ==============================
# LOGIN VIEW
# ==============================
def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect("dashboard")
        else:
            return render(request, "login.html", {"error": "Invalid credentials"})

    return render(request, "login.html")

# ==============================
# LOGOUT VIEW
# ==============================
def logout_view(request):
    logout(request)
    return redirect('login')


# ==============================
# DASHBOARD VIEW
# ==============================
@login_required
def dashboard(request):
    # If Admin → show all patients
    if request.user.is_staff:
        patients = User.objects.filter(is_staff=False)
        return render(request, "dashboard.html", {
            "patients": patients,
            "admin": True
        })

    # If Patient → show own predictions
    predictions = Prediction.objects.filter(patient=request.user)

    return render(request, "dashboard.html", {
        "predictions": predictions,
        "admin": False
    })


# ==============================
# DISEASE PREDICTION VIEW
# ==============================


@login_required
def predict_view(request):

    if request.method == "POST":

        # Get selected symptoms
        selected_symptoms = request.POST.getlist("symptoms")

        if selected_symptoms:

            # Predict disease
            disease = predict_disease(selected_symptoms)

            # ✅ Save in session (for chatbot + email + other modules)
            request.session['predicted_disease'] = disease

            # Save to database
            Prediction.objects.create(
                patient=request.user,
                symptoms=", ".join(selected_symptoms),
                disease=disease
            )
            # health report
            HealthReport.objects.create(
                 user=request.user,
                disease=disease,
                symptoms=", ".join(selected_symptoms)
            )

            # ✅ Redirect to chatbot with disease
            return redirect(f"/chatbot/?disease={disease}")

        else:
            return render(request, "predict.html", {
                "symptoms_list": SYMPTOMS_LIST,
                "error": "Please select at least one symptom."
            })

    # GET request
    return render(request, "predict.html", {
        "symptoms_list": SYMPTOMS_LIST
    })
##### home remidies
def get_home_remedies(disease):

    disease_lower = disease.lower()

    if any(word in disease_lower for word in ["flu", "cold", "infection", "malaria", "typhoid", "fever"]):
        return [
            "Take complete bed rest",
            "Drink warm fluids and herbal tea",
            "Use steam inhalation",
            "Gargle with warm salt water",
            "Eat light and warm food"
        ]

    elif "diabetes" in disease_lower:
        return [
            "Follow low sugar diet",
            "Eat fiber rich foods",
            "Exercise daily",
            "Monitor blood sugar regularly",
            "Drink plenty of water"
        ]

    elif any(word in disease_lower for word in ["acne", "skin", "allergy", "psoriasis"]):
        return [
            "Apply aloe vera gel",
            "Use cold compress",
            "Wash face with mild cleanser",
            "Avoid oily products",
            "Keep skin moisturized"
        ]

    elif any(word in disease_lower for word in ["hypertension", "heart"]):
        return [
            "Reduce salt intake",
            "Practice deep breathing",
            "Exercise regularly",
            "Eat fruits and vegetables",
            "Avoid stress"
        ]

    else:
        return [
            "Take proper rest",
            "Eat balanced diet",
            "Stay hydrated",
            "Avoid stress",
            "Consult doctor if needed"
        ]
# ==============================
# CHATBOT VIEW (Home Remedies)
# ==============================
@login_required
def chatbot_view(request):
    response = None
    disease = request.GET.get("disease")

    if request.method == "POST":
        disease = request.POST.get("disease")

    if disease:
        disease_lower = disease.lower()

        # CATEGORY DETECTION
        if any(word in disease_lower for word in ["flu", "cold", "infection", "malaria", "typhoid", "fever"]):
            remedies = """
🏠 Home Remedies:
- Take complete bed rest
- Drink warm fluids and herbal tea
- Use steam inhalation
- Gargle with warm salt water
- Eat light and warm food

💊 Precautions:
- Avoid cold drinks
- Wear mask to prevent spread
- Stay hydrated
"""

        elif any(word in disease_lower for word in ["diabetes"]):
            remedies = """
🏠 Home Remedies:
- Follow low sugar diet
- Eat fiber rich foods
- Exercise daily
- Monitor blood sugar regularly
- Drink plenty of water

💊 Precautions:
- Avoid sweets and processed food
- Maintain healthy weight
- Take medications on time
"""

        elif any(word in disease_lower for word in ["acne", "skin", "allergy", "psoriasis"]):
            remedies = """
🏠 Home Remedies:
- Apply aloe vera gel
- Use cold compress
- Wash face with mild cleanser
- Avoid oily products
- Keep skin moisturized

💊 Precautions:
- Avoid scratching
- Stay away from allergens
- Maintain skin hygiene
"""

        elif any(word in disease_lower for word in ["hypertension", "heart"]):
            remedies = """
🏠 Home Remedies:
- Reduce salt intake
- Practice deep breathing
- Exercise regularly
- Eat fruits and vegetables
- Avoid stress

💊 Precautions:
- Monitor blood pressure
- Avoid smoking
- Maintain healthy lifestyle
"""

        else:
            remedies = """
🏠 General Health Advice:
- Take proper rest
- Eat balanced diet
- Stay hydrated
- Avoid stress
- Consult doctor for proper diagnosis
"""

        response = f"""
🩺 Disease: {disease}

{remedies}

⚠ When to See Doctor:
- If symptoms worsen
- If severe pain occurs
- If condition does not improve in few days

✅ Early diagnosis improves recovery.
"""

    return render(request, "chatbot.html", {
        "response": response,
        "disease": disease
    })


# ==============================
# NEARBY DOCTORS VIEW
# ==============================
import requests
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import PatientProfile


@login_required
def doctors_view(request):
    doctors = []

    try:
        profile = PatientProfile.objects.get(user=request.user)

        lat = float(profile.latitude) if profile.latitude else None
        lon = float(profile.longitude) if profile.longitude else None

        # ❌ No location
        if not lat or not lon:
            print("❌ No location found")
            return render(request, "doctors.html", {"doctors": []})

        print("📍 User Location:", lat, lon)

        overpass_url = "https://overpass-api.de/api/interpreter"

        # ✅ Improved query (more tags + better coverage)
        query = f"""
        [out:json][timeout:25];
        (
          node(around:5000,{lat},{lon})["amenity"~"doctors|clinic|hospital"];
          way(around:5000,{lat},{lon})["amenity"~"doctors|clinic|hospital"];
          relation(around:5000,{lat},{lon})["amenity"~"doctors|clinic|hospital"];
        );
        out center;
        """

        response = requests.post(
            overpass_url,
            data=query,
            headers={
                "User-Agent": "CareConnectApp/1.0",
                "Content-Type": "text/plain"
            },
            timeout=30
        )

        if response.status_code != 200:
            print("❌ API Error:", response.status_code)
            return render(request, "doctors.html", {"doctors": []})

        data = response.json()
        elements = data.get("elements", [])

        print("✅ Found:", len(elements))

        for element in elements[:30]:  # limit results
            tags = element.get("tags", {})

            doc_lat = element.get("lat") or element.get("center", {}).get("lat")
            doc_lon = element.get("lon") or element.get("center", {}).get("lon")

            if not doc_lat or not doc_lon:
                continue

            name = tags.get("name", "Medical Facility")

            address_parts = [
                tags.get("addr:housenumber"),
                tags.get("addr:street"),
                tags.get("addr:city"),
                tags.get("addr:postcode"),
            ]
            address = ", ".join([x for x in address_parts if x]) or "Address not available"

            doctors.append({
                "name": name,
                "lat": doc_lat,
                "lon": doc_lon,
                "address": address,
                "website": tags.get("website") or tags.get("contact:website")
            })

    except PatientProfile.DoesNotExist:
        print("❌ Profile not found")

    except Exception as e:
        print("❌ Error:", e)

    return render(request, "doctors.html", {"doctors": doctors})






# bmiii
@login_required
def bmi_view(request):
    if request.method == "POST":
        height = float(request.POST.get("height")) / 100
        weight = float(request.POST.get("weight"))

        bmi = weight / (height * height)

        if bmi < 18.5:
            score = 60
        elif bmi < 25:
            score = 90
        else:
            score = 70

        HealthRecord.objects.create(
            user=request.user,
            height=height,
            weight=weight,
            bmi=bmi,
            health_score=score
        )

        return render(request, "bmi_result.html", {
            "bmi": round(bmi, 2),
            "score": score
        })

    return render(request, "bmi.html")

#whether
@login_required
def weather_alert(request):

    lat = request.GET.get("lat")
    lon = request.GET.get("lon")

    if not lat or not lon:
        return render(request, "weather.html")

    api_key = "7beb9804bf4d179c44795fbdc9ba4b86"   # 🔴 Better to move this to settings.py

    # 🌦 Weather API
    weather_url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={api_key}&units=metric"
    weather_response = requests.get(weather_url)
    weather_data = weather_response.json()

    if weather_response.status_code != 200:
        return render(request, "weather.html", {
            "error": weather_data.get("message")
        })

    temperature = weather_data["main"]["temp"]
    weather_desc = weather_data["weather"][0]["description"]

    # 📍 Reverse Geocoding API (Accurate City Name)
    geo_url = f"http://api.openweathermap.org/geo/1.0/reverse?lat={lat}&lon={lon}&limit=1&appid={api_key}"
    geo_response = requests.get(geo_url)
    geo_data = geo_response.json()

    if geo_data:
        city = geo_data[0].get("name", "Unknown Location")
        state = geo_data[0].get("state", "")
        country = geo_data[0].get("country", "")
        full_location = f"{city}, {state}, {country}"
    else:
        full_location = "Unknown Location"

    # 💡 Smart Suggestion Logic
    if temperature <= 15:
        suggestion = "Cold weather. High flu risk. Wear warm clothes."
    elif 15 < temperature <= 30:
        suggestion = "Pleasant weather. Maintain hydration and stay active."
    else:
        suggestion = "Hot weather. Risk of dehydration. Drink more water."

    return render(request, "weather.html", {
        "temperature": temperature,
        "city": full_location,
        "weather_desc": weather_desc,
        "suggestion": suggestion
    })
#Email view


@login_required
def email_reminder(request):

    # ✅ Get disease from session
    disease = request.session.get('predicted_disease')

    if not disease:
        return render(request, "email.html", {
            "message": "No disease found. Please predict disease first."
        })

    if request.method == "POST":

        # ✅ Get email from form input
        user_email = request.POST.get("email")

        if not user_email:
            return render(request, "email.html", {
                "disease": disease,
                "message": "Please enter a valid email."
            })

        # ✅ Get remedies from your chatbot logic
        remedies = get_home_remedies(disease)
        remedy_text = "\n".join(remedies)

        subject = "Health Reminder"
        message = f"""
Hello,

Based on your condition ({disease}):

{remedy_text}

Stay healthy!
"""

        try:
            send_mail(
                subject,
                message,
                settings.EMAIL_HOST_USER,   # sender (your system email)
                [user_email],               # receiver (user input email)
                fail_silently=False
            )

            return render(request, "email.html", {
                "disease": disease,
                "message": "✅ Reminder sent successfully!"
            })

        except Exception as e:
            return render(request, "email.html", {
              "disease": disease,
                "message": f"❌ Error: {str(e)}"
            })

    return render(request, "email.html", {
        "disease": disease
    })
###emergency 
@login_required
def emergency_view(request):

    emergency_numbers = {
        "Ambulance": "102",
        "Emergency": "108",
        "Police": "100",
        
    }

    return render(request, "emergency.html", {
        "numbers": emergency_numbers
    })

##dowmloaed report
@login_required
def download_report(request):

    user = request.user
    report = HealthReport.objects.filter(user=user).last()

    if not report:
        return HttpResponse("No report available")

    disease = report.disease
    symptoms = report.symptoms
    bmi = request.session.get('bmi')

    remedies = get_home_remedies(disease)

    emergency_numbers = [
        "Ambulance: 102",
        "Emergency: 108",
        "Police: 100",
        "Fire: 101"
    ]

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="health_report.pdf"'

    doc = SimpleDocTemplate(response)
    styles = getSampleStyleSheet()

    content = []

    # 🔴 TITLE
    content.append(Paragraph("<font size=20 color='darkblue'><b>Smart Healthcare Report</b></font>", styles['Title']))
    content.append(Spacer(1, 25))

    # 👤 USER INFO
    content.append(Paragraph("<b>👤 User Information</b>", styles['Heading2']))
    content.append(Spacer(1, 10))
    content.append(Paragraph(f"Name: <b>{user.username}</b>", styles['Normal']))
    content.append(Paragraph(f"Email: {user.email}", styles['Normal']))
    content.append(Spacer(1, 20))

    # ⚖ BMI
    content.append(Paragraph("<b>⚖ BMI Details</b>", styles['Heading2']))
    content.append(Spacer(1, 10))
    content.append(Paragraph(f"Your BMI: <font color='green'><b>{bmi if bmi else 'Not Calculated'}</b></font>", styles['Normal']))
    content.append(Spacer(1, 20))

    # 🩺 DISEASE
    content.append(Paragraph("<b>🩺 Predicted Disease</b>", styles['Heading2']))
    content.append(Spacer(1, 10))
    content.append(Paragraph(f"<font color='blue'><b>{disease}</b></font>", styles['Normal']))
    content.append(Spacer(1, 20))

    # 🤒 SYMPTOMS
    content.append(Paragraph("<b>🤒 Symptoms</b>", styles['Heading2']))
    content.append(Spacer(1, 10))
    content.append(Paragraph(symptoms, styles['Normal']))
    content.append(Spacer(1, 20))

    # 🏠 REMEDIES
    content.append(Paragraph("<b>🏠 Home Remedies</b>", styles['Heading2']))
    content.append(Spacer(1, 10))

    for remedy in remedies:
        content.append(Paragraph(f"• {remedy}", styles['Normal']))
        content.append(Spacer(1, 6))

    content.append(Spacer(1, 20))

    # 🚨 EMERGENCY
    content.append(Paragraph("<b>🚨 Emergency Contacts</b>", styles['Heading2']))
    content.append(Spacer(1, 10))

    for number in emergency_numbers:
        content.append(Paragraph(number, styles['Normal']))
        content.append(Spacer(1, 5))

    content.append(Spacer(1, 25))

    # FOOTER
    content.append(Paragraph("<i>Stay healthy! Early diagnosis saves lives.</i>", styles['Normal']))

    doc.build(content)

    return response
####Report history
@login_required
def report_history(request):

    reports = HealthReport.objects.filter(user=request.user)

    return render(request, "report_history.html", {
        "reports": reports
    })